const accountLists = [
  {
    "username": "nu7lcrypto@gmail.com",
    "password": "Lkjsdf12312#"
  },

  {
    "username": "bioco.jbsa@gmail.com",
    "password": "Hiwatari11211@"
  },

  {
    "username": "MiyaBaker14345@gmail.com",
    "password": "8mIyaBAKeR0916"
  },

  {
    "username": "vincentnash321@gmail.com",
    "password": "3nASHVincent6271"
  },

  // for more users just copy paste the form as many as your accounts
];

module.exports = {
  accountLists
};